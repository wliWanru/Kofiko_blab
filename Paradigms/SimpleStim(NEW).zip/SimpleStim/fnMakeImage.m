function bSuccess = fnMakeImage(cond)
%
% Copyright (c) 2008 Shay Ohayon, California Institute of Technology.
% This file is a part of a free software. you can redistribute it and/or modify
% it under the terms of the GNU General Public License as published by
% the Free Software Foundation (see GPL.txt)

global g_strctParadigm
strImageList = num2str(cond);
ImageParameter.ImageKind = g_strctParadigm.ImageKind.Buffer(1,:,g_strctParadigm.ImageKind.BufferIdx);
ImageParameter.StimulusSizePix = g_strctParadigm.StimulusSizePix.Buffer(1,:,g_strctParadigm.StimulusSizePix.BufferIdx);
ImageParameter.SF_CyclePerDeg = g_strctParadigm.SF_CyclePerDeg.Buffer(1,:,g_strctParadigm.SF_CyclePerDeg.BufferIdx);
ImageParameter.BarWidth = g_strctParadigm.BarWidth.Buffer(1,:,g_strctParadigm.BarWidth.BufferIdx);
ImageParameter.Contrast = g_strctParadigm.Contrast.Buffer(1,:,g_strctParadigm.Contrast.BufferIdx);
ImageParameter.SurfaceColor = g_strctParadigm.SurfaceColor.Buffer(1,:,g_strctParadigm.SurfaceColor.BufferIdx);
ImageParameter.StimulusPos = g_strctParadigm.StimulusPos.Buffer(1,:,g_strctParadigm.StimulusPos.BufferIdx);
ImageParameter.Orientation = g_strctParadigm.Orientation.Buffer(1,:,g_strctParadigm.Orientation.BufferIdx);

ImageParameter.PPD = g_strctParadigm.PixelPerDegree;
switch cond
    case 1
        ImageParameter.ImageKind = 1;
        ImageParameter.Parameter_Name{1} = 'Orientation';
        ImageParameter.Parameter_Value{1} = [0:15:345]';
        for i = 1:length(ImageParameter.Parameter_Value{1});
        ImageParameter.Cond_Name{i} = num2str(ImageParameter.Parameter_Value{1}(i));
        end
    case 2
        ImageParameter.ImageKind = 2;
        ImageParameter.Parameter_Name{1} = 'Orientation';
        ImageParameter.Parameter_Value{1} = [0:15:345]';
        for i = 1:length(ImageParameter.Parameter_Value{1});
        ImageParameter.Cond_Name{i} = num2str(ImageParameter.Parameter_Value{1}(i));
        end
    case 3
        ImageParameter.ImageKind = 1;
        ImageParameter.Parameter_Name{1} = 'SF_CyclePerDeg';
        ImageParameter.Parameter_Value{1} = [0.2:0.4:2]';
        for i = 1:length(ImageParameter.Parameter_Value{1});
        ImageParameter.Cond_Name{i} = num2str(ImageParameter.Parameter_Value{1}(i));
        end
    case 4
        ImageParameter.ImageKind = 1;
        ImageParameter.Parameter_Name{1} = 'StimulusSizePix';
        ImageParameter.Parameter_Value{1} = [50:25:300]';
        for i = 1:length(ImageParameter.Parameter_Value{1});
        ImageParameter.Cond_Name{i} = num2str(ImageParameter.Parameter_Value{1}(i));
        end
    case 5
        ImageParameter.ImageKind = 3;
        ImageParameter.Parameter_Name{1} = 'SurfaceColor';
        ImageParameter.Parameter_Name{2} = 'BackgroundColor';
        ImageParameter.Parameter_Name{3} = 'StimulusPos';
        ImageParameter.Cond_Name = {'p11','p12','p21','p22'};
        ImageParameter.Parameter_Value{1} = [0 128 128 0]';
        ImageParameter.Parameter_Value{2} = repmat([128 0 0 128]',1,3);
        theta = mod(ImageParameter.Orientation/180*pi,pi);
        pos(1:2,:) = repmat([ImageParameter.StimulusPos]-[cos(pi/2+theta) sin(pi/2+theta)]*ImageParameter.StimulusSizePix/2,2,1);
        pos(3:4,:) = repmat([ImageParameter.StimulusPos]+[cos(pi/2+theta) sin(pi/2+theta)]*ImageParameter.StimulusSizePix/2,2,1); 
        ImageParameter.Parameter_Value{3} = pos([1 4 2 3],:);
    case 6
        ImageParameter.ImageKind = 3;
        ImageParameter.Parameter_Name{1} = 'SurfaceColor';
        ImageParameter.Parameter_Value{1} = [0 255 ]';
        ImageParameter.Cond_Name = {'Black', 'White'};      
end


g_strctParadigm.Parameter_Name = ImageParameter.Parameter_Name;
g_strctParadigm.Parameter_Value = ImageParameter.Parameter_Value;

fnParadigmToStimulusServer('PauseButRecvCommands');

if fnParadigmToKofikoComm('IsPaused')
    fnParadigmToStimulusServer('Resume');
    fnParadigmToStimulusServer('MakeImageList',ImageParameter);
    fnParadigmToStimulusServer('Pause');
else
    fnParadigmToStimulusServer('MakeImageList',ImageParameter);
end





bSuccess  = false;

fnParadigmToStimulusServer('PauseButRecvCommands');

fnParadigmToKofikoComm('ClearMessageBuffer');
fnParadigmToKofikoComm('DisplayMessageNow','Making Image ...');
fnLog('Switching to a new list');
disp('Stuck');
% This will pass on the message even if the draw cycle is paused....
strctDesign = fnMakeImageAux(ImageParameter);
if isempty(strctDesign)
    % Loading failed!
    return;
end;
g_strctParadigm.m_bJustLoaded = true;
g_strctParadigm.m_strctDesign = strctDesign;
iNumMediaInBlock = length(strctDesign.Image);

if isfield(g_strctParadigm,'ImageList')
    fnTsSetVarParadigm('ImageList',strImageList);
else
    g_strctParadigm.m_strctStimulusParams =fnTsSetVar(g_strctParadigm.m_strctStimulusParams,'ImageList',num2str(cond));
end


fnTsSetVarParadigm('Designs', strctDesign);
fnDAQWrapper('StrobeWord', fnFindCode('Image List Changed'));

g_strctParadigm.m_iLastStimulusPresentedIndex  = 0;
g_strctParadigm.m_strctCurrentTrial = [];
fnParadigmToKofikoComm('ResetStat');

if g_strctParadigm.m_bRandom
    [fDummy,g_strctParadigm.DisplayOrder] = sort(rand(1,iNumMediaInBlock));
    
else
    g_strctParadigm.DisplayOrder = 1:iNumMediaInBlock;
end
% Update order and  blocks

% acBlockNames = {strctDesign.m_strctBlocksAndOrder.m_astrctBlocks.m_strBlockName};
% acBlockNames = acBlockNames(strctDesign.m_strctBlocksAndOrder.m_astrctBlockOrder(1).m_aiBlockIndexOrder);
% acOrderNames = {strctDesign.m_strctBlocksAndOrder.m_astrctBlockOrder.m_strOrderName};
%
% % if isfield(g_strctParadigm,'m_strctControllers')
% %     set(g_strctParadigm.m_strctControllers.m_hBlockOrderPopup,'String',acOrderNames,'value',1);
% %     set(g_strctParadigm.m_strctControllers.m_hBlockLists,'String',acBlockNames,'value',1);
% % end
%
%
if g_strctParadigm.m_iMachineState > 0
    g_strctParadigm.m_iMachineState = 2; % This will prevent us to get stuck waiting for some stimulus server code
end
g_strctParadigm.m_bDoNotDrawThisCycle = true; % first, allow initialization of stuff, like selection of next image from the NEW image list


% Deal with StatServer Later
% if fnParadigmToStatServerComm('IsConnected')
%     if isempty(g_strctParadigm.m_strctDesign.m_a2bStimulusToCondition)
%         % There is no category file defiend for this list.
%         iNumStimuli =  length( g_strctParadigm.m_strctDesign.m_astrctMedia);
%         g_strctParadigm.m_strctStatServerDesign.TrialTypeToConditionMatrix = zeros(iNumStimuli,0);
%         g_strctParadigm.m_strctStatServerDesign.ConditionOutcomeFilter = cell(0);
%         g_strctParadigm.m_strctStatServerDesign.ConditionNames = cell(0);
%         g_strctParadigm.m_strctStatServerDesign.ConditionVisibility = [];
%     else
        NumConditions = iNumMediaInBlock;
        Matrix = zeros(NumConditions,NumConditions);
        for i = 1:NumConditions
            Matrix(i,i) = 1;
        end
        g_strctParadigm.m_strctStatServerDesign.TrialTypeToConditionMatrix = Matrix;
        g_strctParadigm.m_strctStatServerDesign.ConditionOutcomeFilter = cell(1,NumConditions); % No need for fancy averaging according
        % to trial outcome, because we are going to drop all bad
        % fixations...
        g_strctParadigm.m_strctStatServerDesign.DesignName = num2str(cond);
        g_strctParadigm.m_strctStatServerDesign.ConditionNames = ImageParameter.Cond_Name;
        g_strctParadigm.m_strctStatServerDesign.ConditionVisibility = ones(1,NumConditions);
%     end
fnParadigmToStatServerComm('SendDesign', g_strctParadigm.m_strctStatServerDesign);
%
% end

bSuccess  = true;
return;





 