1. This verison includes movable fixation point.
